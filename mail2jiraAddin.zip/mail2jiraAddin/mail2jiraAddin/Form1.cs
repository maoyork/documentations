﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Net;
using System.Windows.Forms;
using Outlook = Microsoft.Office.Interop.Outlook;
using System.IO;
using System.Web.Script.Serialization;

namespace mail2jiraAddin
{
    public partial class FrmCreateJira : Form
    {
        public Outlook.MailItem MailItem;
        public FrmCreateJira()
        {
            InitializeComponent();
        }

        private void FrmCreateJira_Load(object sender, EventArgs e)
        {
            if (MailItem != null)
            {
                string id = generateMailId();
                string url = "g.cn?id=" + id;
                webBrowser_main.Navigate(url);
            }

        }

        private string generateMailId()
        {
            string id;
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create("");
                request.Method = "POST";
                request.Accept = "";
                request.ContentType = "application/json";
                byte[] buffer = Encoding.UTF8.GetBytes("");
                request.ContentLength = buffer.Length;
                request.GetRequestStream().Write(buffer, 0, buffer.Length);
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                using (StreamReader reader = new StreamReader(response.GetResponseStream(), Encoding.UTF8))
                {
                    string responseBody = reader.ReadToEnd();
                    var serializer = new JavaScriptSerializer();
                    var obj = serializer.Deserialize<List<string>>(responseBody);
                    if (obj != null && obj.Count > 0)
                    {
                        id = obj[0];
                    }
                }
            }
            catch (Exception ex)
            {
            }
            return id;
        }
    }
}
