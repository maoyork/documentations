﻿namespace mail2jiraAddin
{
    partial class FrmCreateJira
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.webBrowser_main = new System.Windows.Forms.WebBrowser();
            this.SuspendLayout();
            // 
            // webBrowser_main
            // 
            this.webBrowser_main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowser_main.Location = new System.Drawing.Point(0, 0);
            this.webBrowser_main.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser_main.Name = "webBrowser_main";
            this.webBrowser_main.Size = new System.Drawing.Size(810, 516);
            this.webBrowser_main.TabIndex = 0;
            // 
            // FrmCreateJira
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(810, 516);
            this.Controls.Add(this.webBrowser_main);
            this.Name = "FrmCreateJira";
            this.Text = "Mail2Jira";
            this.Load += new System.EventHandler(this.FrmCreateJira_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.WebBrowser webBrowser_main;
    }
}